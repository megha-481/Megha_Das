package EcomercePlatform;

import java.util.*;
import java.util.Arrays;


public class SearchTest {
    public static void main(String[] args) {
        Product[] products = {
            new Product(4, "Shirt", "Apparel"),
            new Product(2, "Phone", "Electronics"),
            new Product(3, "Shoes", "Apparel"),
            new Product(1, "Laptop", "Electronics")
        };

        int searchId = 3;
        Product foundProductLinear = SearchAlgorithms.linearSearch(products, searchId);
        System.out.println("Linear Search Result: " + (foundProductLinear != null ? foundProductLinear : "Not found"));

        Product foundProductBinary = SearchAlgorithms.binarySearch(products, searchId);
        System.out.println("Binary Search Result: " + (foundProductBinary != null ? foundProductBinary : "Not found"));
    }
}

