/**
 * 
 */
/**
 * 
 */
module AdapterPatternExample {
}