package SingletonExample;

class Logger {
	
	private static Logger single= null;
	public String s;
	
	private Logger() {
		s= "Follow the singleTon pattern";
	}
	
	public static synchronized Logger getInstance() {
		
		if (single== null) {
			single= new Logger();
		}
		
		return single;
	}
}


public class Test{
	public static void main(String[] args) {
		
		Logger x= Logger.getInstance();
		Logger y= Logger.getInstance();
		Logger z= Logger.getInstance();
		
		System.out.println("The hash value of x "+ x.hashCode());
		System.out.println("The hash value of y "+ y.hashCode());
		System.out.println("The hash value of z "+ z.hashCode());
		
		
		
	}
}