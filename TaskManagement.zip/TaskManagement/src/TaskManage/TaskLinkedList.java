package TaskManage;

public class TaskLinkedList {
 private TaskNode head;

 public TaskLinkedList() {
     head = null;
 }

 public void addTask(Task task) {
     TaskNode newNode = new TaskNode(task);
     if (head == null) {
         head = newNode;
     } else {
         TaskNode current = head;
         while (current.next != null) {
             current = current.next;
         }
         current.next = newNode;
     }
 }

 public Task searchTaskById(int taskId) {
     TaskNode current = head;
     while (current != null) {
         if (current.task.getTaskId() == taskId) {
             return current.task;
         }
         current = current.next;
     }
     return null;
 }

 public void traverseTasks() {
     TaskNode current = head;
     while (current != null) {
         System.out.println(current.task);
         current = current.next;
     }
 }

 public void deleteTaskById(int taskId) {
     if (head == null) {
         System.out.println("List is empty.");
         return;
     }

     if (head.task.getTaskId() == taskId) {
         head = head.next;
         return;
     }

     TaskNode current = head;
     TaskNode previous = null;
     while (current != null && current.task.getTaskId() != taskId) {
         previous = current;
         current = current.next;
     }

     if (current == null) {
         System.out.println("Task with ID " + taskId + " not found.");
         return;
     }

     previous.next = current.next;
 }
}
