package TaskManage;

public class TaskLinkedListTest {
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        taskList.addTask(new Task(1, "Complete project report", "In Progress"));
        taskList.addTask(new Task(2, "Review code", "Pending"));
        taskList.addTask(new Task(3, "Prepare for presentation", "Completed"));

        System.out.println("All Tasks:");
        taskList.traverseTasks();

        System.out.println("\nSearching for task with ID 2:");
        Task task = taskList.searchTaskById(2);
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println("\nDeleting task with ID 1:");
        taskList.deleteTaskById(1);

        System.out.println("\nAll Tasks after deletion:");
        taskList.traverseTasks();
    }
}
