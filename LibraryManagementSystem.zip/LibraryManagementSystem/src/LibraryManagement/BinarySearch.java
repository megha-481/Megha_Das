package LibraryManagement;


import java.util.List;

public class BinarySearch {
	public static Book searchByTitle(List<Book> books, String title) {
		int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            Book midBook = books.get(mid);

            int comparison = title.compareToIgnoreCase(midBook.getTitle());
            if (comparison == 0) {
                return midBook;
            } else if (comparison < 0) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        }
        return null; 
    }
}

