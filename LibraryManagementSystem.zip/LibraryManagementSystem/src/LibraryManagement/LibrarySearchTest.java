package LibraryManagement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LibrarySearchTest {
    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "The Great Gatsby", "F.Fitzgerald"));
        books.add(new Book(2, "To Kill a Mockingbird", "Harper Lee"));
        books.add(new Book(3, "1984", "Orwell"));
        books.add(new Book(4, "Moby Dick", "Melville"));

        //books.sort(Comparator.comparing(Book::getTitle()));//(Comparator.comparing(Book::getTitle));
        Collections.sort(books, new Comparator<Book>() {
            @Override
            public int compare(Book b1, Book b2) {
               return b1.getTitle().compareTo(b2.getTitle());
            }
        });

        System.out.println("Linear Search:");
        Book linearResult = LinearSearch.searchByTitle(books, "1984");
        if (linearResult != null) {
            System.out.println(linearResult);
        } else {
            System.out.println("Book not found.");
        }

        System.out.println("\nBinary Search:");
        Book binaryResult = BinarySearch.searchByTitle(books, "1984");
        if (binaryResult != null) {
            System.out.println(binaryResult);
        } else {
            System.out.println("Book not found.");
        }
    }
}
