package ObservePattern;

public class Test {
	public static void main (String[] args) {
        StockMarket stockMarket = new StockMarket();
        
        Observer mobileApp = new MobileApp("Mobile App 1");
        Observer webApp = new WebApp("Web App 1");
        
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);
        
        System.out.println("Stock price changed to 500.00");
        stockMarket.setStockPrice(500.00);
        
        stockMarket.deregisterObserver(mobileApp);
        
        System.out.println("Stock price changed to 200.00");
        stockMarket.setStockPrice(200.00);
	}

}
