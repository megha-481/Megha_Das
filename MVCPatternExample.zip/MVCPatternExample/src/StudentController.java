
public class StudentController {
    private Student student;
    private StudentView studentView;

    public StudentController(Student student, StudentView studentView) {
        this.student = student;
        this.studentView = studentView;
    }

    // Setters
	/*
	 * public void setStudentName(String name) { student.setName(name); }
	 */

    public void setStudentId(int id) {
        student.setId(id);
    }
	/*
	 * public void setStudentGrade(String grade) { student.setGrade(grade); }
	 */

    // Getters
	/*
	 * public String getStudentName() { return student.getName(); }
	 */

    public int getStudentId() {
        return student.getId();
    }
	/*
	 * public String getStudentGrade() { return student.getGrade(); }
	 */

    // Update view
    public void updateView() {
        studentView.displayStudentDetails(student.getName(), student.getId(), student.getGrade());
    }
}
