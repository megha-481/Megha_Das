package DecoretorPattern;

public class Test {
 public static void main(String[] args) {
     Notifier emailNotifier = new EmailNotifier();

     Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);

     Notifier slackAndSMSNotifier = new SlackNotifierDecorator(smsNotifier);

     slackAndSMSNotifier.send("Hello, world!");
 }
}

