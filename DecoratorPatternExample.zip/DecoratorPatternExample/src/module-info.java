/**
 * 
 */
/**
 * 
 */
module DecoratorPatternExample {
}