package DependencyPattern;

public interface CustomerRepository {
 Customer findCustomerById(int id);
}
