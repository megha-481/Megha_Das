package StrategtPattern;

public class Test {
	public static void main (String[] args) {
        PaymentStrategy creditCard = new CreditCardPayment("1234-5678-9876-5432", "John Doe");
        PaymentContext paymentContext = new PaymentContext(creditCard);
        
        paymentContext.executePayment(150.00);
        
        PaymentStrategy payPal = new PayPalPayment("john.doe@example.com");
        paymentContext.setPaymentStrategy(payPal);
        
        paymentContext.executePayment(200.00);
	}

}
