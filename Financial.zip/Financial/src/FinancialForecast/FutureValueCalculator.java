package FinancialForecast;

public class FutureValueCalculator {
    
    public static double calculateFutureValue(double currentValue, double growthRate, int years) {
        if (years == 0) {
            return currentValue;
        }
        double futureValueInPreviousYear = calculateFutureValue(currentValue, growthRate, years - 1);
        return futureValueInPreviousYear * (1 + growthRate);
    }
    
    public static void main(String[] args) {
        double currentValue = 1000; 
        double growthRate = 0.02;   
        int years = 15;             
        
        double futureValue = calculateFutureValue(currentValue, growthRate, years);
        System.out.printf("The future value after %d years is: %.2f\n", years, futureValue);
    }
}
