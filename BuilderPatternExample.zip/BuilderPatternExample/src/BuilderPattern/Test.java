package BuilderPattern;

public class Test {
	public static void main (String[] args) {
		 Computer gamingComputer = new Computer.Builder()
		            .setCPU("Intel i9")
		            .setRAM(32)
		            .setStorage(1024)
		            .setSSD(true)
		            .setGraphicsCard("NVIDIA RTX 3080")
		            .build();
		 
		        Computer officeComputer = new Computer.Builder()
		            .setCPU("Intel i5")
		            .setRAM(16)
		            .setStorage(512)
		            .setSSD(false)
		            .build();
		
		        System.out.println(gamingComputer);
		        System.out.println(officeComputer);
	}

}
