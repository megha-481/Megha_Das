package FactoryMethod;

public class WordDocument implements Document {
	
	public void open() {
		System.out.println("Open the word document");
	}

}
