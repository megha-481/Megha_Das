package FactoryMethod;

public interface Document {
	void open();

}
