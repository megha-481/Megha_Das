package FactoryMethod;

public abstract class DocumentFactory {
	public abstract Document createDocument();
      
}
