package FactoryMethod;

public class Concrete{
	public static void main (String[] args) {
		
	}

}
