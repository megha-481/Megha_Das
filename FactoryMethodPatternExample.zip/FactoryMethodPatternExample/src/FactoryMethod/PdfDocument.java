package FactoryMethod;

public class PdfDocument implements Document {
	public void open() {
		System.out.println("Open the pdf document");
	}

}
