package FactoryMethod;

public class ExcelDocument implements Document {
	public void open() {
		System.out.println("Open the excel document");
	}

}
